package cumt.e.testsensor;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteDatabase.CursorFactory;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

public class DatabaseHelper extends SQLiteOpenHelper{
    //带全部参数的构造函数，此构造函数必不可少
    public DatabaseHelper(Context context, String name, CursorFactory factory, int version) {
        super(context, name, factory, version);
    }
    @Override
    public void onCreate(SQLiteDatabase db) {
        //创建数据表sql语句 并 执行
        String sql = "create table ACCELEROMETER(x real,y real,z real,t varchar(50))";//加速度数据表，默认会创建一个自增id
        db.execSQL(sql);
        sql = "create table GRAVITY(x real,y real,z real,t varchar(50))";//重力传感器数据表
        db.execSQL(sql);
        sql = "create table GYROSCOPE(x real,y real,z real,t varchar(50))";//陀螺仪数据表,t是时间格式为 "YYYY-MM-DD HH:MM:SS.SSS" 的日期
        db.execSQL(sql);

    }
    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

    }

}