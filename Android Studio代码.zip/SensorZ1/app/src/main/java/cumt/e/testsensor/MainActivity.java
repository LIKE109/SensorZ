package cumt.e.testsensor;


import androidx.appcompat.app.AppCompatActivity;

import android.database.sqlite.SQLiteDatabase;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import java.text.SimpleDateFormat;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.util.Date;

public class MainActivity extends AppCompatActivity implements View.OnClickListener, SensorEventListener {

    private SensorManager sManager;
    private Sensor mSensorAccelerometer;
    private Sensor mSensorGYROSCOPE;
    private Sensor mSensorGRAVITY;
    private TextView tv_step;
    private TextView acc;//加速度
    private TextView gyrx;
    private TextView gyry;
    private TextView gyrz;
    private Button btn_start;
    private double accnum;
    private String step ="time" ;
    private double lstValue = 0;  //上次的值
    private double curValue = 0;  //当前值
    private double gyrxValue;
    private double gyryValue;
    private double gyrzValue;

    private boolean motiveState = true;   //是否处于运动状态
    private boolean processState = false;
    private SQLiteDatabase db;
    private float[] value;
    SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS");
    String datetime;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        sManager = (SensorManager) getSystemService(SENSOR_SERVICE);
        mSensorGYROSCOPE = sManager.getDefaultSensor(Sensor.TYPE_GYROSCOPE);//陀螺仪
        sManager.registerListener(this, mSensorGYROSCOPE, SensorManager.SENSOR_DELAY_GAME);//采样率50Hz
        mSensorAccelerometer = sManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER);//加速度
        sManager.registerListener(this, mSensorAccelerometer, SensorManager.SENSOR_DELAY_GAME);//采样率50Hz
        mSensorGRAVITY = sManager.getDefaultSensor(Sensor.TYPE_GRAVITY);//重力
        sManager.registerListener(this, mSensorGRAVITY, SensorManager.SENSOR_DELAY_GAME);//采样率50Hz
        //依靠DatabaseHelper的构造函数创建数据库
        DatabaseHelper dbHelper = new DatabaseHelper(MainActivity.this, "sensor_db",null,1);
        db = dbHelper.getWritableDatabase();
        bindViews();
    }

    private void bindViews() {

        tv_step = (TextView) findViewById(R.id.tv_step);
        acc = (TextView) findViewById(R.id.acc);
        gyrx = (TextView) findViewById(R.id.gyrx);
        gyry = (TextView) findViewById(R.id.gyry);
        gyrz = (TextView) findViewById(R.id.gyrz);
        btn_start = (Button) findViewById(R.id.btn_start);
        btn_start.setOnClickListener(this);
    }


    @Override
    public void onSensorChanged(SensorEvent event) {
        double range = 15;   //设定一个精度范围
        double range1 = 0.5;
        if (processState == true) {
            switch (event.sensor.getType()) {
                case Sensor.TYPE_GYROSCOPE:
                    value = event.values;
                    datetime = formatter.format(System.currentTimeMillis());//获取当前时间
                    //插入数据库
                    String sql2 = "INSERT  INTO GYROSCOPE (x ,y ,z ,t) VALUES (" + value[0] + "," + value[1] + "," + value[2] + ",'" + datetime + "') ";
                    db.execSQL(sql2);
                    gyrxValue=value[0];
                    gyryValue=value[1];
                    gyrzValue=value[2];
                    if (gyrxValue>range1){
                        gyrx.setText("gyrx:"+gyrxValue);
                    }
                    if (gyryValue>range1){
                        gyry.setText("gyry:"+gyryValue);
                    }
                    if (gyrzValue>range1){
                        gyrz.setText("gyrz:"+gyrzValue);
                    }
                    break;
                case Sensor.TYPE_GRAVITY:
                    value = event.values;
                    datetime = formatter.format(System.currentTimeMillis());//获取当前时间
                    //插入数据库
                    String sql3 = "INSERT  INTO GRAVITY (x ,y ,z ,t) VALUES (" + value[0] + "," + value[1] + "," + value[2] + ",'" + datetime + "') ";
                    db.execSQL(sql3);
                    break;
                case Sensor.TYPE_ACCELEROMETER:
                    value = event.values;
                    datetime = formatter.format(System.currentTimeMillis());//获取当前时间
                    //插入数据库
                    String sql1 = "INSERT  INTO ACCELEROMETER (x ,y ,z ,t) VALUES (" + value[0] + "," + value[1] + "," + value[2] + ",'" + datetime + "') ";
                    db.execSQL(sql1);
                    curValue = magnitude(value[0], value[1], value[2]);   //计算当前的模


                    Date nowtime=new Date(System.currentTimeMillis());
                    SimpleDateFormat sd=new SimpleDateFormat("HH:mm:ss");
                    String now=sd.format(nowtime);
                    step=now;

                    tv_step.setText(step+"");

                    accnum=Math.abs(curValue-lstValue);

                    if (curValue>range){
                        acc.setText("acc:"+accnum);
                        lstValue=curValue;
                    }
                    break;

            }
        }

    }

    @Override
    public void onAccuracyChanged(Sensor sensor, int accuracy) {}

    @Override
    public void onClick(View v) {
        step= "time";
        accnum=0;
        gyrxValue = 0;
        gyryValue = 0;
        gyrzValue = 0;
        acc.setText("acceleration");
        tv_step.setText("time");
        gyrx.setText("gyroscopeX");
        gyry.setText("gyroscopeY");
        gyrz.setText("gyroscopeZ");

        if (processState == true) {
            btn_start.setText("start");
            processState = false;
            //将db文件复制到Download文件夹下
            copyFile("/data/data/cumt.e.testsensor/databases/sensor_db","/data/data/cumt.e.testsensor/databases/sensor.db");
        } else {
            btn_start.setText("stop");
            db.execSQL("delete from ACCELEROMETER");//清空数据表
            db.execSQL("delete from GYROSCOPE");//清空数据表
            db.execSQL("delete from GRAVITY");//清空数据表

            processState = true;
        }
    }

    //向量求模
    public double magnitude(float x, float y, float z) {
        double magnitude = 0;
        magnitude = Math.sqrt(x * x + y * y + z * z);
        return magnitude;
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        sManager.unregisterListener(this);
    }
    /**
     * 复制单个文件
     *
     * @param oldPath$Name String 原文件路径+文件名 如：data/user/0/com.test/files/abc.txt
     * @param newPath$Name String 复制后路径+文件名 如：data/user/0/com.test/cache/abc.txt
     * @return <code>true</code> if and only if the file was copied;
     * <code>false</code> otherwise
     */
    public boolean copyFile(String oldPath$Name, String newPath$Name) {
        try {
            File oldFile = new File(oldPath$Name);
            if (!oldFile.exists() || !oldFile.isFile() || !oldFile.canRead()) {
                return false;
            }


            FileInputStream fileInputStream = new FileInputStream(oldPath$Name);    //读入原文件
            FileOutputStream fileOutputStream = new FileOutputStream(newPath$Name);

            byte[] buffer = new byte[1024];
            int byteRead;
            while ((byteRead = fileInputStream.read(buffer)) != -1) {
                fileOutputStream.write(buffer, 0, byteRead);
            }
            fileInputStream.close();
            fileOutputStream.flush();
            fileOutputStream.close();
            return true;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

}
